import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth/next';
import { db } from '@ecokuku/db';
import { adminAuthOptions } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(adminAuthOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 },
      );
    }

    const searchParams = request.nextUrl.searchParams;
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '20');
    const batchId = searchParams.get('batchId');

    const skip = (page - 1) * limit;

    const where: any = {};

    if (batchId) {
      where.batchId = batchId;
    }

    const [logs, total] = await Promise.all([
      db.vaccination.findMany({
        where,
        skip,
        take: limit,
        include: {
          batch: {
            select: { id: true, batchNumber: true },
          },
        },
        orderBy: { dateAdministered: 'desc' },
      }),
      db.vaccination.count({ where }),
    ]);

    return NextResponse.json({
      data: logs,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Health logs fetch error:', error);
    return NextResponse.json(
      { error: 'Failed to fetch health logs' },
      { status: 500 },
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(adminAuthOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 },
      );
    }

    const body = await request.json();
    const {
      batchId,
      vaccineType,
      dateAdministered,
      dosage,
      administeredBy,
      notes,
    } = body;

    if (!vaccineType || !dateAdministered) {
      return NextResponse.json(
        { error: 'Missing required fields: vaccineType, dateAdministered' },
        { status: 400 },
      );
    }

    const log = await db.vaccination.create({
      data: {
        batchId: batchId || null,
        vaccineType,
        dateAdministered: new Date(dateAdministered),
        dosage,
        administeredBy,
        notes,
      },
      include: {
        batch: {
          select: { id: true, batchNumber: true },
        },
      },
    });

    return NextResponse.json(
      {
        message: 'Vaccination record created successfully',
        log,
      },
      { status: 201 },
    );
  } catch (error) {
    console.error('Vaccination record creation error:', error);
    return NextResponse.json(
      { error: 'Failed to create vaccination record' },
      { status: 500 },
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const session = await getServerSession(adminAuthOptions);

    if (!session?.user?.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 401 },
      );
    }

    const body = await request.json();
    const { vaccinationId, ...updateData } = body;

    if (!vaccinationId) {
      return NextResponse.json(
        { error: 'Vaccination ID is required' },
        { status: 400 },
      );
    }

    const log = await db.vaccination.update({
      where: { id: vaccinationId },
      data: updateData,
      include: {
        batch: {
          select: { id: true, batchNumber: true },
        },
      },
    });

    return NextResponse.json({
      message: 'Vaccination log updated successfully',
      log,
    });
  } catch (error) {
    console.error('Vaccination log update error:', error);
    return NextResponse.json(
      { error: 'Failed to update vaccination log' },
      { status: 500 },
    );
  }
}
